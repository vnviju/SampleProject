<?php

namespace app\models;

use yii\db\ActiveRecord;

class Fruits extends ActiveRecord
{
    public  function attributes()
    {
        return [
            'id',
            'fruitname',
            'model',
            'family',
            'ordername',
            'genus',
            'nutrition',
            'favorite'
        ];
    }
    public static function tableName()
    {
        return 'fruits'; // Specify the name of the "fruits" table in your database
    }

    public static function primaryKey()
    {
        return ['id']; // Specify the primary key column name of the "fruits" table
    }

    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'fruitname' => 'Fruit Name',
            'model' => 'Model',
            'family' => 'Family',
            'genus' => 'Genus',
            'favorite'  => 'Favorite',
            // Add more attribute labels as needed
        ];
    }

    public function countFavorites()
    {
        $count = Fruits::find()
        ->where(['favorite' => 1])
        ->count();

        return $count;
    }

}


