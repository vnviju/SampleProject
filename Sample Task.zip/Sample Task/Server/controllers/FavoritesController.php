<?php

namespace app\controllers;
use Yii;

use yii\web\Response;
use yii\helpers\ArrayHelper;
use yii\helpers\Json;
use yii\data\ActiveDataProvider;
class FavoritesController extends \yii\rest\ActiveController {

    
    public $modelClass = 'app\models\Fruits';



    public function actions()
    {
        return [
            'index' => [
                'class' => 'yii\rest\IndexAction',
                'modelClass' => $this->modelClass,
                'prepareDataProvider' => function () {

                    try{

                        // Create an instance of ActiveDataProvider and configure it with pagination settings
                        $dataProvider = new ActiveDataProvider([
                            'query' => $this->modelClass::find(), 
                            'pagination' => [
                                'pageSize' => 10, // Set the page size as needed
                            ],
                        ]);
        
                   
                        $query = $dataProvider->query;
                        $query->andFilterWhere(['favorite' => '1']); 

              	
                        // Get the current page and total number of pages
                            $currentPage = Yii::$app->request->get('page', 1);
                        $totalPages = ceil($dataProvider->totalCount / $dataProvider->pagination->pageSize);

                        // Get the model records from data provider
                        $models = $dataProvider->getModels();

                        // Convert the array of arrays to an array of objects
                        $responseContent = ArrayHelper::toArray($models, [
                        ]);
                        // Set response format and content
                        Yii::$app->response->format = Response::FORMAT_JSON;
                        Yii::$app->response->data = Json::encode([
                            'totalPages' => $totalPages, // Set the total number of pages in the response
                            'error' => "false", // Set an error flag to false indicating no errors
                            'message' => '', // Set an empty error message initially
                            'data' => $responseContent, // Set the model records in the response
                         
                        ]);
        
                        // Set CORS headers
                        Yii::$app->response->headers->set('Access-Control-Allow-Origin', '*'); // Set the allowed origin(s) here
                        Yii::$app->response->headers->set('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
                        Yii::$app->response->headers->set('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');

                        
                        return Yii::$app->response;
                    } catch (\Exception $e) {
                       // Catch the exception and generate an error response
                        Yii::$app->response->format = Response::FORMAT_JSON;
                        Yii::$app->response->data = Json::encode([
                            'totalPages' => 0, // Set totalPages to 0 indicating no data
                            'error' => true, // Set error flag to true indicating there is an error
                            'message' => $e->getMessage(), // Include the error message in the response
                            'data' => [], // Set empty data array
                        ]);
                        return Yii::$app->response;
                    }
                },
            ],
        ];
    }
    

}   