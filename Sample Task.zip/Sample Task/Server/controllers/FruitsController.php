<?php

namespace app\controllers;



use Yii;
use yii\web\Response;
use yii\helpers\ArrayHelper;
use yii\helpers\Json;
use yii\data\ActiveDataProvider;


class FruitsController extends \yii\rest\ActiveController {

    
    public $modelClass = 'app\models\Fruits';



    public function actions()
    {


        return [
            'index' => [
                'class' => 'yii\rest\IndexAction',
                'modelClass' => $this->modelClass,
                'prepareDataProvider' => function () {

                    try{

                        // Create an instance of ActiveDataProvider and configure it with pagination settings
                        $dataProvider = new ActiveDataProvider([
                            'query' => $this->modelClass::find()->select(['id', 'fruitname','family','ordername','genus','favorite']), // Specify the columns to select
                            'pagination' => [
                                'pageSize' => 10, // Set the page size as needed
                            ],
                        ]);
                        
              
                        // Get the search parameters from the request
                        $fruitName = Yii::$app->request->get('fruit', '');
                        $family = Yii::$app->request->get('family', '');

                    // Apply filters to the query based on the search parameters
                    if ($fruitName !== "") {
                        $query = $dataProvider->query;
                        $query->andFilterWhere(['like', 'fruitname', $fruitName]);
               
                    }

                    if ($family !== "") {
                        $query = $dataProvider->query;
                        $query->andFilterWhere(['like', 'family', $family]);
               
                    }

                        // call the method to get favorite count
                        $favoritesCount = $this->getFavoriteCount();

                        // Get the current page and total number of pages
                        $currentPage = Yii::$app->request->get('page', 1);
                        $totalPages = ceil($dataProvider->totalCount / $dataProvider->pagination->pageSize);

                        // Get the model records from data provider
                        $models = $dataProvider->getModels();

                        // Convert the array of arrays to an array of objects
                        $responseContent = ArrayHelper::toArray($models, []);

                        // Set response format and content
                        Yii::$app->response->format = Response::FORMAT_JSON;
                        Yii::$app->response->data = Json::encode([
                            'totalPages' => $totalPages, // Set the total number of pages in the response
                            'data' => $responseContent, // Set the model records in the response
                            'error' => "false", // Set an error flag to false indicating no errors
                            'message' => '', // Set an empty error message initially
                            'favoritesCount' => $favoritesCount, // Set an empty error message initially
                  
                        ]);
        
                        // Set CORS headers
                        Yii::$app->response->headers->set('Access-Control-Allow-Origin', '*'); // Set the allowed origin(s) here
                        Yii::$app->response->headers->set('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
                        Yii::$app->response->headers->set('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');

                        
                    return Yii::$app->response;
                    }catch (\Exception $e) {
                        // Catch the exception and generate an error response
                        Yii::$app->response->format = Response::FORMAT_JSON;
                        Yii::$app->response->data =Json::encode( [
                            'error' =>"true" ,
                            'message' => $e->getMessage(), // Include the error message in the response
                        ]);
                        return Yii::$app->response;
                    }
                },
            ],
        ];
    }
    
    public function actionUpdateFavorite ()
    {
        $id = Yii::$app->request->post('id');
        $favorite = Yii::$app->request->post('favorite');

      
       try {
        // Find the model by ID

        $modelClass = $this->modelClass;
        $model = $modelClass::findOne($id);

        // If the model is not found, throw an exception
        if (!$model) {
                throw new \yii\web\NotFoundHttpException('The requested page does not exist.');
        }

        $favoritesCount = $this->getFavoriteCount();
        if ($favoritesCount >= 10 && $favorite == 1)
        {
            // Return error response if model save fails
            $errors = $model->getErrors();
            Yii::$app->response->format = Response::FORMAT_JSON;
            Yii::$app->response->data = Json::encode([
                'error' => true,
                'message' => 'There are more than 10 favorites.',
                'favoritesCount' => $favoritesCount
                  
            ]);
        }
 
        else
        {
       
            // Update the 'favorite' column based on the value of $favorite
            $model->favorite = $favorite ;

            $favoritesCount = $this->getFavoriteCount();
      
            // Save the model
            if ($model->save()) {
                // Return success response
                Yii::$app->response->format = Response::FORMAT_JSON;
                Yii::$app->response->data = Json::encode([
                    'error' => "false",
                    'message' => 'Favorite updated successfully.',
                    'favoritesCount' => $favoritesCount
              
                ]);
            } else {
                // Return error response if model save fails
                $errors = $model->getErrors();
                Yii::$app->response->format = Response::FORMAT_JSON;
                Yii::$app->response->data = Json::encode([
                    'error' => true,
                    'message' => 'Failed to update favorite. Please try again later.',
                    'favoritesCount' => $favoritesCount
              
                ]);
            }
        }
    } catch (\Exception $e) {
        // Catch the exception and generate an error response
        Yii::$app->response->format = Response::FORMAT_JSON;
        Yii::$app->response->data = Json::encode([
            'error' => "true",
            'message' => "In Exception". $e->getMessage(),
            'favoritesCount' => $favoritesCount
              
        ]);
    }

    return Yii::$app->response;
}

    private  function getFavoriteCount()
    {
        $favoritesCount = $this->modelClass::find()->where(['favorite' => 1])->count(); // Execute the query and get the count
       
        return  $favoritesCount ;
    }

}   