<?php


// Require the ProjConfig.php file
require_once 'ProjConfig.php';
//class to send emails
require_once 'EmailSender.php';


try {
    // Create a new cURL resource
    $ch = curl_init();

    // Set the URL and options for the request
    $url = 'https://fruityvice.com/api/fruit/all';
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CAINFO, __DIR__ . '/Vendor/cert/cacert.pem');
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);

      curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));

    // Execute the request and get the response
    $response = curl_exec($ch);

    // Close the cURL resource
    curl_close($ch);

    // Check if cURL request was successful
    if ($response === false) {  
        throw new Exception('Error making cURL request: ' . curl_error($ch));
    }

    // Decode the JSON response
 
    try{
        $fruits = json_decode($response);

        // Check if decoding was successful
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception('Error decoding JSON response: ' . json_last_error_msg());
        }
    
    }catch(Exception $e){
        echo "Failed to decode JSON: " . $e->getMessage();
        return ;
    }

    
    // Connect to MySQL database
    try
    {
        $mysqli = new mysqli(DBSERVER,DBUSER, DBPASS , DBNAME);
        if ($mysqli->connect_errno) {
            throw new Exception("Failed to connect to MySQL: " . $mysqli->connect_error);
        }
    }
    catch(Exception $e){
        echo "Failed to connect to MySQL: " . $e->getMessage();
        return ;
    }
     $fruitsInserted = "";
    // Insert fruits into MySQL database
    foreach ($fruits as $fruit) {
        $name = $fruit->name;
        $family = $fruit->family;
        $order = $fruit->order;
        $genus = $fruit->genus;
        $nutritionData = isset($fruit->nutritions) ? $fruit->nutritions : null; // Check if 'nutrition' key exists.
    
        if (is_string($nutritionData)) {
            try {
                $nutritionData = json_decode($nutritionData, true); // Decode JSON string into associative array
         
                if (json_last_error() !== JSON_ERROR_NONE) {
                    echo "Error decoding nutrition data for fruit $name: " . json_last_error_msg() . PHP_EOL;
                    continue; // Skip to the next fruit
                }
            } catch(Exception $e){
                echo "Failed to decode JSON: " . $e->getMessage();
                return ;
            }
       
        }
  
        $nutritionData = isset($nutritionData) ? json_encode($nutritionData) : null; // Convert back to JSON string
        // Check if fruit already exists in the database
        try{
            $stmt = $mysqli->prepare("SELECT fruitname FROM fruits WHERE fruitname = ?");
            $stmt->bind_param("s", $name);
            $stmt->execute();
            $stmt->store_result();
            $num_rows = $stmt->num_rows;
            $stmt->close();
            if ($num_rows > 0) {
                echo "$name already exists in the database." . PHP_EOL;
                $fruitsInserted = $fruitsInserted . "$name already exists in the database."  .PHP_EOL. "\r\n";
            } else {
                // Insert fruit into the database
                $stmt = $mysqli->prepare("INSERT INTO fruits (fruitname,family,ordername,genus,nutrition) VALUES (?, ?, ?, ?, ?)");
                $stmt->bind_param("sssss", $name, $family, $order, $genus, $nutritionData);
                if ($stmt->execute()) {
                    echo "$name inserted into the database." . PHP_EOL;
                    $fruitsInserted = $fruitsInserted . "$name inserted into the database." .PHP_EOL. "\r\n";
                } else {
                    echo "Error inserting $name into the database: " . $stmt->error . PHP_EOL;
                    $fruitsInserted = $fruitsInserted . "Error inserting $name into the database: " .$stmt->error .PHP_EOL. "\r\n";
                }
                $stmt->close(); // to lose the stmt object
            }
        } 
        
        catch(Exception $e){
            echo "Failed in Select / Insert Statement: " . $e->getMessage();
            return ;
        }

    }

    // Close database connection
    $mysqli->close();


    // Send email using Gmail's SMTP service
    $recipientEmail = RECIPIENT_EMAIL; // Replace with the recipient email address
    $subject = "Fruits Data Inserted into Database"; // 
    $senderEmail = SENDER_EMAIL;
    $senderName = SENDER_NAME;

    $emailSender = new EmailSender();
    $emailSender->setRecipient($recipientEmail);
    $emailSender->setSenderMail($senderEmail);
    $emailSender->setSenderName($senderName);
    $emailSender->setSubject($subject);
    $emailSender->setBody($fruitsInserted);



    if ($emailSender->sendEmail()) {
        echo  $emailSender->getSuccessMessage();
        return 0;
    
    } else {
        echo 'Failed to send email: ' . $emailSender->getError();

        return 0;
        // Handle the error, such as logging, displaying an error message, etc.

    }
}
catch(Exception $e){
    // Handle the exception
    echo ('Error: ' . $e->getMessage() . PHP_EOL);

}

?>