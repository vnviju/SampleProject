<?php



// Set SMTP configuration for Gmail - here app password is being used 
Const SMTP_HOST = "smtp.gmail.com";
Const SMTP_PORT = 587;

Const SMTP_USER = "vnviju@gmail.com"; // Replace with your Gmail email address
Const SMTP_PASS = "wjpnwmlvqmldvujy"; // Replace with your Gmail email password

Const DBSERVER = "localhost";
Const DBNAME = "dp";
Const DBUSER = "root";
Const DBPASS = "";


Const RECIPIENT_EMAIL = "vaidyag@yahoo.com";
Const SENDER_EMAIL = "vnviju@gmail.com";
Const SENDER_NAME = "Vijay";


//global $smtpHost, $smtpPort, $smtpUserName, $smtpPass, $dbName,$dbUserName,$dbPass,$dbServer;


?>