<?php



// Set SMTP configuration for Gmail - here app password is being used 
Const SMTP_HOST = "smtp.gmail.com";
Const SMTP_PORT = 587;

Const SMTP_USER = ""; // Replace with email address
Const SMTP_PASS = ""; // Replace with email passes

Const DBSERVER = "localhost";  // Replace with DB Server
Const DBNAME = "dp";   // Replace with DB Name
Const DBUSER = ""; // Replace wiht user id
Const DBPASS = ""; //Replcace with Password


Const RECIPIENT_EMAIL = ""; // Replace with email address
Const SENDER_EMAIL = ""; //Replace with email address
Const SENDER_NAME = ""; //Replace with Name


//global $smtpHost, $smtpPort, $smtpUserName, $smtpPass, $dbName,$dbUserName,$dbPass,$dbServer;


?>