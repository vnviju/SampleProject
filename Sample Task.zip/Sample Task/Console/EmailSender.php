
<?php

// Require the ProjConfig.php file
require_once 'ProjConfig.php';

// Include PHP Mailer files
require_once 'vendor\phpmailer\phpmailer\src\PHPMailer.php';
require_once 'vendor\phpmailer\phpmailer\src\SMTP.php';
require_once 'vendor\phpmailer\phpmailer\src\Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

class EmailSender
{
    const SMTP_DEBUG = SMTP::DEBUG_OFF; // Replace this line if you want to see debug output

    private $email;
    private $senderName;
    private $error;
    private $sucessMessage;

    private $senderEmail;
    private $password;
    private $recipient;
    private $subject;
    private $body;

    public function setRecipient($recipient)
    {
        $this->recipient = $recipient;
    }

    public function setSenderMail($senderEmail)
    {
        $this->senderEmail = $senderEmail;
    }

    public function getError()
    {
        return $this->error;
    }

    public function getSuccessMessage()
    {
        return $this->sucessMessage;
    }
    public function setSenderName($senderName)
    {
        $this->senderName = $senderName;
    }

    public function setSubject($subject)
    {
        $this->subject = $subject;
    }

    public function setBody($body)
    {
        $this->body = $body;
    }

    public function sendEmail()
    {
        // Validate sender email address
        if (!filter_var($this->senderEmail, FILTER_VALIDATE_EMAIL)) {
            $this->error = "Invalid sender email address";
            return false;
        }

        // Validate sender name
        if (empty($this->senderName)) {
            $this->error = "Sender name is required";
            return false;
        }

        // Validate recipient email address
        if (empty($this->recipient)) {
            $this->error = "Recipient email address is empty";
            return false;
        }

        // Validate recipient email address
        if (!filter_var($this->recipient, FILTER_VALIDATE_EMAIL)) {
            $this->error = "Invalid recipient email address";
            return false;
        }

        // Check if SMTP settings are configured
        if (empty(SMTP_HOST) || empty(SMTP_USER) || empty(SMTP_PASS) || empty(SMTP_PORT)) {
            $this->error ="SMTP settings are not configured properly";
            return false;

        }

        try{
            $mail = new PHPMailer(true);

        }
        catch(Exception $e){
             $this->error = 'Error sending email: ' . $mail->ErrorInfo . PHP_EOL;
            return false;

        }
      
        try {
            // Attempt to establish a connection to the SMTP server
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = SMTP_PORT;
            $mail->SMTPAuth = true;
            $mail->Username = SMTP_USER;
            $mail->Password = SMTP_PASS;
            $mail->Host = SMTP_HOST;
            $mail->SMTPDebug = self::SMTP_DEBUG;
           //$mail->SMTPDebug = SMTP::DEBUG_SERVER; // Enable debug mode
            //$mail->Debugoutput = function($str, $level) { echo "$level: $str"; }; // Output debug messages to the screen
            $mail->isSMTP();
        } catch (Exception $e) {
            $this->error = "Failed to connect to SMTP server. Please check  SMTP Settings or Mail Server Status: " . $e->getMessage() . PHP_EOL;
            return false;

        }
        

        $mail->setFrom($this->senderEmail, $this->senderName);
        $mail->addAddress($this->recipient);
        $mail->isHTML(true);
        $mail->Subject = $this->subject;
        $mail->Body = $this->body;

        try {
            $mail->send();
            $this->sucessMessage  ='Email sent successfully.' . PHP_EOL;
            return true;
        } catch (Exception $e) {
            $this->error = 'Error sending email: ' . $mail->ErrorInfo . PHP_EOL;
            return false;
        }
    }
}
?>

